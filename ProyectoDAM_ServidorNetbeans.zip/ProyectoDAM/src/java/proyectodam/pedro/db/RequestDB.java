/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectodam.pedro.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import proyectodam.pedro.pojos.Request;

/**
 *
 * @author Pedro
 */
public class RequestDB {
    public static ArrayList<Request> getAllRequest() throws Exception{
        Connection conexion = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionDB.getConexion();
            ArrayList<Request> requests = new ArrayList<>();

            ps = conexion.prepareStatement("SELECT * FROM solicitudes");
            rs = ps.executeQuery();
            
            Request request;
            
            while(rs.next()){
                request = new Request(rs.getInt("PK_ID"), rs.getString("nombre"), rs.getString("lugar"), rs.getString("queja")/*, rs.getString("imagen")*/);
                requests.add(request);
            }
            
            return requests;
            
        } catch (Exception ex) {
           throw ex;
        }finally {
            if (ps != null) ps.close();
            if (rs != null) rs.close();
            if (conexion != null) conexion.close(); 
        }
    }
    
    static public Request getRequest(int id) throws Exception{
    
        Connection conexion = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
    
        try {
            conexion = ConexionDB.getConexion();
            ps = conexion.prepareStatement("SELECT * FROM solicitudes WHERE PK_ID = " + id);
            rs = ps.executeQuery();
            
            
            
            while(rs.next()){
                Request registro = new Request();
                
                registro.setPK_ID(rs.getInt("PK_ID"));
                registro.setNombre(rs.getString("Nombre"));
                registro.setLugar(rs.getString("Lugar"));
                registro.setQueja(rs.getString("Queja"));
                /*registro.setImagen(rs.getString("Imagen"));*/
                
                 
                return registro;
            }
            
           
            
        } catch (Exception e) {
           throw e;
        }finally {
            if (ps != null) ps.close();
            if (rs != null) rs.close();
            if (conexion != null) conexion.close();    
        }
        return null;
    }
    
    static public void addRquest(Request registro) throws Exception{
    
        Connection conexion = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
    
        try {
            conexion = ConexionDB.getConexion();
            String str;
            if  (registro.getPK_ID() != -1){
                str = "INSERT INTO solicitudes (PK_ID, Nombre, Lugar, Queja) VALUES (" 
                        + registro.getPK_ID() + ",'" + registro.getNombre() + "','" + registro.getLugar() + "','" + registro.getQueja() + /*"','" + registro.getImagen() +*/ "')";
            }else {
                str = "INSERT INTO solicitudes (Nombre, Lugar, Queja) VALUES ("
                        + "'" + registro.getNombre() + "','" + registro.getLugar() + "','" + registro.getQueja() + /*"','" + registro.getImagen() + */"')";
            }
            
            ps = conexion.prepareStatement(str);
            ps.executeUpdate();
    
        } catch (Exception e) {
           throw e;
        }finally {
            if (ps != null) ps.close();
            if (rs != null) rs.close();
            if (conexion != null) conexion.close();    
        }
    }
    
    static public void delRequest(int id) throws Exception{
        Connection conexion = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
    
        try {
            conexion = ConexionDB.getConexion();
            ps = conexion.prepareStatement("DELETE FROM solicitudes WHERE PK_ID = " + id + "");
            ps.executeUpdate();
        } catch (Exception e) {
           throw e;
        }finally {
            if (ps != null) ps.close();
            if (rs != null) rs.close();
            if (conexion != null) conexion.close();    
        }
    }
    
    static public void updateRequest(Request registro) throws Exception{
        Connection conexion = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
    
        try {
            conexion = ConexionDB.getConexion();
            String str = "UPDATE solicitudes SET Nombre = '" + registro.getNombre() + "'"
                    + ", Lugar = '" + registro.getLugar() + "'"
                    + ", Queja = '" + registro.getQueja() + "'"
                    /*+ ", Imagen = '" + registro.getImagen() + "'"*/
                    + " WHERE PK_ID = " + registro.getPK_ID();

            ps = conexion.prepareStatement(str);
            ps.executeUpdate();
    
        } catch (Exception e) {
           throw e;
        }finally {
            if (ps != null) ps.close();
            if (rs != null) rs.close();
            if (conexion != null) conexion.close();    
        }
    }      
}
