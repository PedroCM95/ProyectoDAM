/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectodam.pedro.pojos;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pedro
 */
@XmlRootElement
public class Request {
    private int PK_ID;
    private String nombre;
    private String lugar;
    private String queja;
    /*private String imagen;*/
    
     public Request() {
    }

public Request(int PK_ID, String nombre, String lugar, String queja/*, String imagen*/) {
        this.PK_ID = PK_ID;
        this.nombre = nombre;
        this.lugar = lugar;
        this.queja = queja;
        /*this.imagen = imagen;*/
    }

    public int getPK_ID() {
        return PK_ID;
    }

    public void setPK_ID(int PK_ID) {
        this.PK_ID = PK_ID;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getQueja() {
        return queja;
    }

    public void setQueja(String queja) {
        this.queja = queja;
    }

   /* public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }*/
    
    
}
