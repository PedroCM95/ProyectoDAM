/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectodam.pedro;

import com.google.gson.Gson;
import java.util.Date;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import proyectodam.pedro.db.RequestDB;
import proyectodam.pedro.pojos.Request;


/**
 * REST Web Service
 *
 * @author Pedro
 */
@Path("solicitudes")
public class ProyectoResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of ProyectoResource
     */
    public ProyectoResource() {
    }

    /**
     * Retrieves representation of an instance of proyectodam.pedro.ProyectoResource
     * @return an instance of java.lang.String
     */
    @GET
    @Path("prueba")
    @Produces(MediaType.TEXT_PLAIN)
    public String getXml() {
        //TODO return proper representation object
        return("funciona");
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllRequest() {
        try {
            List<Request> requests = RequestDB.getAllRequest();
            String json = new Gson().toJson(requests);
            return Response.ok(json, MediaType.APPLICATION_JSON).build();
        } catch (Exception ex) {
            return Response.status(Response.Status.SEE_OTHER).entity("Error al consultar los datos").build();
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addRequest (Request registro){
    try{
        RequestDB.addRquest(registro);
        Date fecha = new Date();
        System.out.println(fecha.toString() + ": Se ha añadido - addRequest " + registro.getPK_ID());
        String json = "{  \"id\": \"" + String.valueOf(registro.getPK_ID()) + "\" }";
        return Response.ok(json, MediaType.APPLICATION_JSON).build();
    } catch (Exception e){
        return Response.status(Response.Status.SEE_OTHER).entity("No se ha podido insertar el  registro: " + registro.getPK_ID()).build();
    }
    }
    
    @PUT
    @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateRequest (Request registro, @PathParam("id") int id){
    try{
        RequestDB.updateRequest(registro);
        Date fecha = new Date();
        System.out.println(fecha.toString() + ": Se ha actualizado - updateRequest " + registro.getPK_ID());
        String json = "{  \"id\": \"" + String.valueOf(registro.getPK_ID()) + "\" }";
        return Response.ok(json, MediaType.APPLICATION_JSON).build();
    } catch (Exception e){
        return Response.status(Response.Status.SEE_OTHER).entity("No se ha podido actualizar el registro: " + registro.getPK_ID()).build();
    }
    }
    
    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delRequest (@PathParam("id") int id){
    try{
        RequestDB.delRequest(id);
        Date fecha = new Date();
        System.out.println(fecha.toString() + ": Se ha borrado - delRequest " + id);
        String json = "{  \"id\": \"" + id + "\" }";
        return Response.ok(json, MediaType.APPLICATION_JSON).build();
    } catch (Exception e){
        return Response.status(Response.Status.SEE_OTHER).entity("No se ha podido borrar el  registro: " + id).build();
    }
    }
    
    

    /**
     * PUT method for updating or creating an instance of ProyectoResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
